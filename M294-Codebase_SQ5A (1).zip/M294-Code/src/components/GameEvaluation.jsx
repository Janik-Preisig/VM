export default function GameEvaluation(props) {
  return (
    <div>
      <h1>Game Evaluation</h1>
      <h2>Hooray, we're done!</h2>
    </div>
  );
}