
export default function XYZ(){
  return (
    <>
      <h1>XYZ</h1>
      <p>is a dead end :-)</p>
    </>
  )
}