export default function Rules() {
  return (
    <div>
      <h1>Fightclub Rules</h1>
      <ol>
        <li>You don't talk about fight club.</li>
        <li>You don't talk about fight club.</li>
        <li>Someone yells stop, goes limp, taps out, the fight is over.</li>
        <li>Only two guys to a fight.</li>
        <li>Only one fight a time</li>
        <li>No shirts, no shoes</li>
        <li>Fights will go on as long as they have to.</li>
        <li>If this is your first night at fight club, you have to fight.</li>
      </ol>
    </div>
  );
}