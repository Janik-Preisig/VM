import {Link, Outlet} from 'react-router-dom'

export default function Layout(){
  return (<>
    <header>
        <h1>Welcome to the WISS Quiz</h1>
        <nav className='main-nav'>
          <Link to="/">Home</Link>
          <Link to="rules">Regeln</Link>
          <Link to="impressum">Impressum</Link>
        </nav>
      </header>
      <hr />
      <Outlet />
  </>)
}