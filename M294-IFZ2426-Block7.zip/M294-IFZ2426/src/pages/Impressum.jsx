export default function Impressum() {
  return (
    <div>
      <h1>Impressum</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
    </div>
  );
}