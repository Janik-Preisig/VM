
import { useEffect, useState } from "react";
import Question from "../components/Question";

export default function GameSession() {

  const [score, setScore] = useState(0)
  const [index, setIndex] = useState(0)
  const [questions, setQuestions] = useState([])

  useEffect(()=>{
    fetch("http://localhost:8080/questions")
      .then(response => response.json())
      .then(questions => setQuestions(questions))
  }, [])

  useEffect(()=> {
    console.log("Questions have been loaded")
  },[questions])

  const auswertFun = (answer) => {
    console.log("GameSession received answer: "+answer)
    if (answer === true){
      setScore(score+1)
    }
    setIndex(index+1)
  }


  return (
    <div>
      <h1>GameSession</h1>
      <h2>Score: {score}</h2>
      {index < questions.length &&
        <Question question={ questions[index] }
            fun={auswertFun}/>
      }
      {
        index >= questions.length &&
        <h2>Game over</h2>
      }
    </div>
  );
}