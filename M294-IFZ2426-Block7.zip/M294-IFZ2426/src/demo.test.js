function sum(a,b) {
  return a + b;
}

test("should add two numbers", () => {
  const erg = sum(1, 2);
  expect(erg).toBe(3);
});

test("should always be true", ()=> {
  expect(1).toBe(1);
});