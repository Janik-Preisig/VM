import './App.css';
import GameSession from './pages/GameSession';
import Rules from './pages/Rules';
import Impressum from './pages/Impressum';
import Layout from './pages/Layout'
import XYZ from './pages/XYZ'
import { Link, Routes, Route } from 'react-router-dom';

function App() {

  return (
    <>
      <Routes>
        <Route path="xyz" element={<XYZ />} />
        <Route path="/" element={<Layout />}  >
          <Route index element={<GameSession />} />
          <Route path="impressum" element={<Impressum />} />
          <Route path="rules" element={<Rules />} />
        </Route>
      </Routes>

    </>
  );
}

export default App;
