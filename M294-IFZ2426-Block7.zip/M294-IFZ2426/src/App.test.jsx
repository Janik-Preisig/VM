import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import App from './App';
import { MemoryRouter } from 'react-router-dom';

// Hier wird der Mock als JSX-Komponente für GlobalNavigation (doc)
// mit Lambda-return-Funktion erstellt
jest.mock("./pages/GameSession",
  () => () => <div>QED</div>)

jest.mock("./pages/Rules",()=>()=> <div>RULI</div>)

// hier kommt der eigentliche Test
describe("Dies ist ein Testpaket für die App-Komponente", () => {
  it ("should render", async() => {
    // Arrange
    let gesuchterText = "QED"
    // Act
    render(<MemoryRouter><App /></MemoryRouter>)
    // Assert: Mockup-Text wird im gerendert DOM erwartet
    expect(screen.getByText(gesuchterText)).toBeInTheDocument()
  })

  it ("should render rules", async()=>{
    const gesuchterText = "RULI"
    render(<MemoryRouter initialEntries={["/rules"]}>
        <App />
      </MemoryRouter>)
    expect(screen.getByText(gesuchterText)).toBeInTheDocument()

  })
})
