import {render, screen} from '@testing-library/react';
import '@testing-library/jest-dom'
import GameSession from './pages/GameSession';


describe("GameSession", () => {
  it ("should render GameSession with question", async() => {
    render(<GameSession />);
    expect(screen.getByText(/gamesession/i)).toBeInTheDocument();
    expect(screen.getByText(/question/i)).toBeInTheDocument();
  });
  /*it ("should have answer buttons enabled", async() => {
    render(<GameSession />);
    const buttons = screen.getAllByRole('button');
    expect(buttons).toHaveLength(3);
    buttons.forEach(button => expect(button).toBeEnabled());
  });*/
})
