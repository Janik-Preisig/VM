import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom'
import Question from './Question';

describe("Question works correctly",()=>{

  it ("should accept correct answer", async() => {
    // Arrange
    const question = {
      question: "What is the answer to life, the universe and everything?",
      answers: ["Answer 1", "3", "42"],
      correctAnswer: "42"
    }
    // Act
    render(<Question question={question} fun={() => {}}/>)
    // Assert
    const q = screen.getByText(question.question)
    expect(q).toBeInTheDocument();
    await userEvent.click(screen.getByText('42'))
    expect(screen.getByText('Yoku dekita')).toBeInTheDocument()
  });
  it ("should reject wrong answer", async() => {
    // Arrange
    const question = {
      question: "What is the answer to life, the universe and everything?",
      answers: ["Answer 1", "3", "42"],
      correctAnswer: "42"
    }
    // Act
    render(<Question question={question} fun={() => {}}/>)
    // Assert
    const q = screen.getByText(question.question)
    expect(q).toBeInTheDocument();
    await userEvent.click(screen.getByText('3'))
    expect(screen.getByText('All wrong')).toBeInTheDocument()
  });
})