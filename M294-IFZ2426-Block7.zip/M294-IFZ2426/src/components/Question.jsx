import Button from "./Button";
import { useState,useEffect } from "react";

export default function Question(props) {

  const clickFun = function(event){
    const answer = event.target.innerHTML
    if (answer === props.question.correct_answer){
      setCorrect(true)
    } else {
      setCorrect(false)
    }
  }

  const [isCorrect, setCorrect] = useState(null)

  // system-hook, wird ausgeführt wenn
  // props.question geupdated wird
  useEffect(()=>{
    setCorrect(null)
  },[props.question])

  return (
    <div>
      <h1>Question</h1>
      <h2>{props.question.question}</h2>
      { (isCorrect === null) &&
        <div className="buttonbar">
          {
            props.question.answers.map((answer) =>
              <Button label={answer}
                      key={answer}
                      fun={clickFun}/>
            )
          }
        </div>
      }
      {
        (isCorrect !== null) && isCorrect && <h1>Yoku dekita</h1>
      }
      {
        (isCorrect !== null) && !isCorrect && <h1>All wrong</h1>
      }
      <button onClick={() => props.fun(isCorrect)}>Next</button>
    </div>
  );
}